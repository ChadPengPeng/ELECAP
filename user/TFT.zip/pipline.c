#include "pipline.h"


u16 frameCache[HEIGHT][WIDTH]={0};
UIobject* cursor;
void graphInit(){
    SCREEN_Init();
    headInit();
    cursor=getHead();
    eventInit();
    //your init object
    recUI(120, 160, 100, 100, BLUE, 2);
    debugUI();
}

int getTimeInterval(){
    static uint32_t lastTick=0;
    uint32_t thisTick=HAL_GetTick();
    int deltaT=(int)(thisTick-lastTick);
    lastTick=thisTick;
    return deltaT;
}

void processEvent(){
    while(haveEvent()){
        Event event = dequeueEvent();
        //write your event process function
        if(event>=0){
            int cursorX=event>>8;
            int cursorY=event&0b11111111;
            UIobject* pointer = getHead();
            while(pointer->next!=NULL){
                pointer=pointer->next;
                if(cursorX<pointer->x+pointer->box[0][0]) continue;
                else if(cursorX>pointer->x+pointer->box[0][1]) continue;
                else if(cursorY<pointer->y+pointer->box[1][0]) continue;
                else if(cursorY>pointer->y+pointer->box[1][1]) continue;
                else cursor=pointer;
            }
        }
        if(cursor->eventListener!=NULL){
            cursor->eventListener(cursor,event);
        }
    }
}

void updataUI(int deltaT){
    UIobject* pointer = getHead();
    while(pointer->next!=NULL){
        pointer=pointer->next;
        if(pointer->update!=NULL)
        pointer->update(pointer, deltaT);
    }
}

void shadeUI(){
    UIobject* pointer = getHead();
    while(pointer->next!=NULL){
        pointer=pointer->next;
        if(pointer->shader!=NULL)
        pointer->shader(pointer);
    }
}



void graph(){
    SetWindow(0,0,WIDTH,HEIGHT);
    for(int i = 0; i < HEIGHT; i++){
        for(int j = 0; j < WIDTH; j++){
            WriteColor(frameCache[i][j]);
        }
    }
}
int deltaT=1;
void nextGraphic(){
    
    deltaT=getTimeInterval();

    //zero
    memset(frameCache,0xFFFF,sizeof(frameCache));

    processEvent();

    updataUI(deltaT);

    shadeUI();

    graph();

    
}