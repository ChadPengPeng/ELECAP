#ifndef __EVENT__
#define __EVENT__

typedef int Event;
enum Event_enum
{
    KEY1=-1,KEY2=-2,KEY3=-3,KEY4=-4 //x<<8+y as touch event
};

typedef struct EventBuffer_struct{
    Event eventList[256];
    unsigned char head;
    unsigned char tail;
} EventBuffer;

extern EventBuffer eventBuffer;
extern void eventInit();
extern void addEvent(Event event);
extern Event dequeueEvent();
extern int haveEvent();
#endif // !__EVENT__