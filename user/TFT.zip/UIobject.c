#include "UIobject.h"

UIobject* head;
void headInit(){
    head=getUIobject();
}

UIobject* getHead(){
    return head;
}

UIobject* getUIobject(){
    UIobject* result = (UIobject*) malloc(sizeof(UIobject));
    result->this=result;
    result->next=NULL;
    result->x=result->y=0;
    result->box[0][0]=result->box[0][1]=result->box[1][0]=result->box[1][1]=0;
    result->eventListener=NULL;
    result->update=NULL;
    result->shader=NULL;
    return result;
}

void insert(UIobject* link, UIobject* node){
    node->next=link->next;
    link->next=node;
}

void priorityInsert(UIobject* node){
    UIobject* pointer = head;
    while(pointer->next != NULL){
        pointer=pointer->next;
        if(node->priority>pointer->priority){
            insert(pointer,node);
            return;
        }
    }
    insert(pointer,node);
}

void delNext(UIobject* node){
    node->next=node->next->next;
    free(node->next);
}