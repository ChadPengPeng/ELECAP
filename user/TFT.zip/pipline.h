#ifndef __PIPLINE__
#define __PIPLINE__

#include "interference.h"
#include "UIobject.h"
#include "event.h"
#include "UIsample.h"
#include "string.h"

#define demicalDigit 8

extern void graphInit();
extern void nextGraphic();

#endif // !__PIPLINE__