#include "UIsample.h"

void grabCursor(UIobject*this, Event event){
    int cursorX=event>>8;
    int cursorY=event&0b11111111;
    this->x=cursorX/2+this->x/2;
    this->y=cursorY/2+this->y/2;
}

void recShader(UIobject* this){
    u16 x,y,dx,dy,color;
    x=this->x;
    y=this->y;
    dx=this->param[0];
    dy=this->param[1];
    color=this->param[2];
    cacheLine(x-dx,y+dy,x+dx-1,y+dy,color);
    cacheLine(x+dx,y+dy,x+dx,y-dy+1,color);
    cacheLine(x+dx,y-dy,x-dx+1,y-dy,color);
    cacheLine(x-dx,y-dy,x-dx,y+dy-1,color);
}

void recUI(u16 centerx, u16 centery, u16 width, u16 height, u16 color, int priority){
    UIobject* result = getUIobject();
    result->x=centerx;
    result->y=centery;
    result->box[0][1]=result->param[0]=width/2;
    result->box[0][0]=-result->param[0];
    result->box[1][1]= result->param[1]=height/2;
    result->box[1][0]=-result->param[1];
    result->param[2]=color;
    result->eventListener=grabCursor;
    result->shader=recShader;
    result->priority=priority;
    priorityInsert(result);
}


extern int deltaT;
#include "touch.h"
void debugShader(){
    //debug
    char fps[16],x[16],y[16];
    sprintf(fps,"fps:%.3d",1000/deltaT);
    sprintf(x,"x:%.3d",360-tp_dev.Y/23);
    sprintf(y,"y:%.3d",256-tp_dev.X/30);
    cacheString(0,0,100,100,12,fps,BLACK);
    cacheString(0,16,100,100,12,x,BLACK);
    cacheString(0,32,100,100,12,y,BLACK);
}

void debugUI(){
    UIobject* result = getUIobject();
    result->priority=255;
    result->shader = debugShader;
    priorityInsert(result);
}

// extern int wave[300];
// void oscShader(UIobject* this){
//     for (int i){
//         cachePoint(x+i,y+wave[i]);
//     }
// }

// void oscUI(){
//     UIobject* result = getUIobject();
//     result->x=0;
//     result->y=0;
//     result->shader=oscShader;
//     return result;
// }