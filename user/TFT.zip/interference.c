#include "interference.h"

u16 FadeColor(u16 color,u16 weight){
    return Migrate((getR(color)*weight)>>8,(getG(color)*weight)>>8,(getB(color)*weight)>>8);
}

void DrawTransparentPoint(u16 x, u16 y, u16 color, u16 weight){
    cachePoint(x,y,FadeColor(color, weight)+FadeColor(getPoint(x,y), 256-weight));
}

void cacheLine(u16 x1, u16 y1, u16 x2, u16 y2, u16 color)
{
    int xDirect,yDirect;
    int xDis,yDis;

    xDirect=sign(x2-x1);
    yDirect=sign(y2-y1);
    xDis=absM(x2-x1);
    yDis=absM(y2-y1);

    int xCursor,yCursor;
    xCursor=0;
    yCursor=0;
    if(xDis>=yDis){
        int yOverflow=0;
        for(int i=0;i<=xDis;i++){
            cachePoint(x1+xCursor,y1+yCursor,color);
            xCursor+=xDirect;
            yOverflow+=2*yDis;
            if(yOverflow>=xDis){
                yCursor+=yDirect;
                yOverflow-=2*xDis;
            }
        }
    }
    else{
        int xOverflow=0;
        for(int i=0;i<=yDis;i++){
            cachePoint(x1+xCursor,y1+yCursor,color);
            yCursor+=yDirect;
            xOverflow+=2*xDis;
            if(xOverflow>=yDis){
                xCursor+=xDirect;
                xOverflow-=2*yDis;
            }
        }
    }
}

void cacheChar(u16 x, u16 y, u8 num, u8 size, u16 color)
{
    u8 temp, t1, t;
    u16 y0 = y;
    u8 csize = (size / 8 + ((size % 8) ? 1 : 0)) * (size / 2); // 得到字体一个字符对应点阵集所占的字节数
    num = num - ' ';                                           // 得到偏移后的值（ASCII字库是从空格开始取模，所以-' '就是对应字符的字库）
    for (t = 0; t < csize; t++)
    {
        if (size == 12)
            temp = asc2_1206[num][t]; // 调用1206字体
        else if (size == 16)
            temp = asc2_1608[num][t]; // 调用1608字体
        else if (size == 24)
            temp = asc2_2412[num][t]; // 调用2412字体
        else if (size == 32)
            temp = asc2_3216[num][t]; // 调用3216字体
        else
            return; // 没有的字库
        for (t1 = 0; t1 < 8; t1++)
        {
            if (temp & 0x80)
                cachePoint(x, y, color);
            temp <<= 1;
            y++;
            if (y >= lcddev.height)
                return; // 超区域了
            if ((y - y0) == size)
            {
                y = y0;
                x++;
                if (x >= lcddev.width)
                    return; // 超区域了
                break;
            }
        }
    }
}

void cacheString(u16 x, u16 y, u16 width, u16 height, u8 size, char *p, u16 color)
{
    u8 x0 = x;
    width += x;
    height += y;
    while ((*p <= '~') && (*p >= ' ')) // 判断是不是非法字符!
    {
        if (x >= width)
        {
            x = x0;
            y += size;
        }
        if (y >= height)
            break; // 退出
        if ((x + size / 2) > lcddev.width)
        {
            x = 0;
            y += size;
        }
        cacheChar(x, y, *p, size, color);
        x += size / 2;
        p++;
    }
}