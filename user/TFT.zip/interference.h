#ifndef __INTERFERENCE__
#define __INTERFERENCE__

#include "bsp_system.h"
#include "dev_lcd.h"
#include "fontInclude.h"

#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE         	 	 0x001F  
#define BRED             0XF81F
#define GRED 			 			 0XFFE0
#define GBLUE			 			 0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			 		 0XBC40 
#define BRRED 			 		 0XFC07 
#define GRAY  			 		 0X8430

#define DARKBLUE      	 0X01CF	
#define LIGHTBLUE      	 0X7D7C	
#define GRAYBLUE       	 0X5458 
 
#define LIGHTGREEN     	 0X841F 
#define LGRAY 			 		 0XC618 

#define LGRAYBLUE        0XA651 
#define LBBLUE           0X2B12 


#define WIDTH 320
#define HEIGHT 240
#define GRAPHICSIZE (WIDTH*HEIGHT)

#define SCREEN_Init() LCD_Init()
#define DrawPoint(x,y,color) LCD_Fast_DrawPoint(x,y,color)
#define SetWindow(sx, sy, width, height) LCD_Set_Window(sx, sy, width, height);LCD_WriteRAM_Prepare()
#define WriteColor(color) LCD_WriteRAM(color)
#define ReadColor(x,y) LCD_ReadPoint(x,y)

#define absM(x) ((x)>0?(x):-(x))
#define sign(x) ((x)>0?1:-1)
#define getR(color) ((color) >> 11)
#define getG(color) (((color) & 0b0000011111100000) >> 5)
#define getB(color) ((color) & 0b0000000000011111)
#define Migrate(R,G,B) (((R)<<11)+((G)<<5)+(B))


extern u16 frameCache[HEIGHT][WIDTH];
#define cachePoint(x,y,color) frameCache[y][x]=(color)
#define getPoint(x,y) (frameCache[y][x])

extern u16 FadeColor(u16 color,u16 weight);
extern void DrawTransparentPoint(u16 x, u16 y, u16 color, u16 weight);
extern void cacheLine(u16 x1, u16 y1, u16 x2, u16 y2, u16 color);
extern void cacheString(u16 x, u16 y, u16 width, u16 height, u8 size, char *p, u16 color);

#endif // !__INTERFERENCE__
